"""
LoRaWAN to InfluxDB Bridge
Listens to MQTT messages from Wazi Gateway, parses XLPP sensor data,
and sends to InfluxDB Cloud.
Handles both encrypted (LoRaWAN) and unencrypted (plain LoRa) packets.
"""

import json
import binascii
import struct
import time
import base64
import requests
import paho.mqtt.client as mqtt
from Crypto.Cipher import AES
from typing import Optional
from datetime import datetime

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════

# MQTT Broker (Wazi Gateway)
MQTT_BROKER = "192.168.0.102"
MQTT_PORT   = 1883
MQTT_TOPIC  = "wazi/sensors/#"

# LoRaWAN ABP Keys
DEVADDR = "AC5BADE2"
APPSKEY = bytes.fromhex("89481B4A09CC80E1964E035E9ECD0ABF")
NWKSKEY = bytes.fromhex("F0F54D38619239041A40DBDFEE53C12F")

# InfluxDB Cloud
INFLUXDB_URL    = "https://eu-central-1-1.aws.cloud2.influxdata.com"
INFLUXDB_BUCKET = "wazi_sensors"
INFLUXDB_ORG    = "andguladzeluka12@gmail.com"
INFLUXDB_TOKEN  = "k7dFdwFKCIsk6bwZjnwKmry9uiw8yAkw7nye1D4ym2Wk8SX84wL41XxhSNWqtTspNnkfjbce3RXL7rT45m5CIQ=="

DEVICE_NAME = "wazi-node"

# ═══════════════════════════════════════════════════════════════
# DECRYPTION
# ═══════════════════════════════════════════════════════════════

def decrypt_lora_payload(payload_hex: str) -> bytes:
    """Decrypt LoRaWAN payload using AES-128 ECB mode."""
    if len(payload_hex) % 32 != 0:
        pad_len = (32 - (len(payload_hex) % 32)) % 32
        payload_hex += "00" * (pad_len // 2)
    
    cipher = AES.new(APPSKEY, AES.MODE_ECB)
    raw = binascii.unhexlify(payload_hex)
    
    out = b""
    for i in range(0, len(raw), 16):
        out += cipher.decrypt(raw[i:i+16])
    
    return out

# ═══════════════════════════════════════════════════════════════
# XLPP PARSER
# ═══════════════════════════════════════════════════════════════

def parse_xlpp(payload: bytes) -> dict:
    """Parse XLPP format sensor data."""
    out = {}
    i, L = 0, len(payload)
    
    while i < L:
        if i + 1 >= L:
            break
        
        data_type = payload[i]
        channel = payload[i + 1]
        
        # Temperature (0x02)
        if data_type == 0x02 and i + 4 <= L:
            val = struct.unpack(">h", payload[i+2:i+4])[0] / 10.0
            if channel == 0x01:
                out["temperature"] = val
            else:
                out[f"temperature_ch{channel}"] = val
            i += 4
        
        # Humidity (0x03)
        elif data_type == 0x03 and i + 3 <= L:
            val = payload[i + 2]
            if channel == 0x02:
                out["relativehumidity"] = float(val)
            else:
                out[f"relativehumidity_ch{channel}"] = float(val)
            i += 3
        
        # Analog input (0x06)
        elif data_type == 0x06 and i + 4 <= L:
            val = struct.unpack(">h", payload[i+2:i+4])[0]
            
            if channel == 0x03:
                out["rainAO"] = int(val)
            elif channel == 0x04:
                out["soundAO"] = int(val)
            elif channel == 0x05:
                out["waterAO"] = int(val)
            else:
                out[f"analog_ch{channel}"] = int(val)
            i += 4
        
        else:
            i += 1
    
    # Calculate percentages
    if "rainAO" in out:
        out["rainPct"] = round(max(0, min(100, (1023 - out["rainAO"]) * 100 / 1023)), 1)
    
    if "soundAO" in out:
        out["soundPct"] = round(max(0, min(100, out["soundAO"] * 100 / 1023)), 1)
    
    if "waterAO" in out:
        out["waterPct"] = round(max(0, min(100, out["waterAO"] * 100 / 1023)), 1)
    
    return out

# ═══════════════════════════════════════════════════════════════
# INFLUXDB
# ═══════════════════════════════════════════════════════════════

def send_to_influxdb(sensor_data: dict, device: str = DEVICE_NAME) -> bool:
    """Send sensor data to InfluxDB Cloud."""
    if not sensor_data:
        return False
    
    ts_ns = int(time.time() * 1e9)
    lines = []
    
    for key, value in sensor_data.items():
        try:
            fv = float(value)
            lines.append(f"{key},device={device} value={fv} {ts_ns}")
        except (ValueError, TypeError):
            continue
    
    if not lines:
        return False
    
    payload = "\n".join(lines)
    headers = {
        "Authorization": f"Token {INFLUXDB_TOKEN}",
        "Content-Type": "text/plain",
        "Accept": "application/json"
    }
    
    url = f"{INFLUXDB_URL}/api/v2/write"
    params = {
        "org": INFLUXDB_ORG,
        "bucket": INFLUXDB_BUCKET,
        "precision": "ns"
    }
    
    try:
        r = requests.post(url, params=params, data=payload, headers=headers, timeout=10)
        
        if r.status_code == 204:
            print(f"   ✅ Sent to InfluxDB: {sensor_data}")
            return True
        else:
            print(f"   ❌ InfluxDB error [{r.status_code}]: {r.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"   ❌ Network error: {e}")
        return False

# ═══════════════════════════════════════════════════════════════
# MQTT PAYLOAD EXTRACTION
# ═══════════════════════════════════════════════════════════════

def extract_payload_hex(mqtt_payload: bytes) -> Optional[str]:
    """Extract hex payload from various MQTT message formats."""
    # Try JSON format
    try:
        obj = json.loads(mqtt_payload.decode("utf-8"))
        
        b64_data = obj.get("data") or obj.get("frm_payload")
        if b64_data:
            return base64.b64decode(b64_data).hex()
        
        if isinstance(obj.get("payload"), str):
            ph = obj["payload"].strip().lower()
            if ph and all(c in "0123456789abcdef" for c in ph):
                return ph
    except Exception:
        pass
    
    # Try ASCII hex string
    try:
        s = mqtt_payload.decode("utf-8").strip().lower()
        if s and all(c in "0123456789abcdef" for c in s):
            return s
    except Exception:
        pass
    
    # Raw binary as hex
    return mqtt_payload.hex()

# ═══════════════════════════════════════════════════════════════
# MQTT CALLBACKS
# ═══════════════════════════════════════════════════════════════

def on_connect(client, userdata, flags, reason_code, properties):
    """Called when connected to MQTT broker."""
    if reason_code == 0:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"🔌 [{timestamp}] MQTT connected, subscribing to {MQTT_TOPIC}")
        client.subscribe(MQTT_TOPIC, qos=0)
    else:
        print(f"❌ MQTT connection failed with code: {reason_code}")

def on_message(client, userdata, msg):
    """Called when a message is received."""
    timestamp = datetime.now().strftime("%H:%M:%S")
    
    try:
        payload_hex = extract_payload_hex(msg.payload)
        if not payload_hex:
            print(f"⚠️  [{timestamp}] No payload on {msg.topic}")
            return
        
        print(f"\n📡 [{timestamp}] {msg.topic}")
        print(f"   HEX: {payload_hex}")
        
        # Try parsing as UNENCRYPTED first (for plain LoRa packets)
        payload_bytes = bytes.fromhex(payload_hex)
        data = parse_xlpp(payload_bytes)
        
        if data:
            print(f"   📊 Parsed (unencrypted): {data}")
            send_to_influxdb(data, device=DEVICE_NAME)
        else:
            # If unencrypted parsing failed, try DECRYPTION (for LoRaWAN packets)
            print(f"   🔐 Trying decryption...")
            decrypted = decrypt_lora_payload(payload_hex)
            print(f"   🔓 Decrypted: {decrypted.hex()}")
            
            data = parse_xlpp(decrypted)
            if data:
                print(f"   📊 Parsed (decrypted): {data}")
                send_to_influxdb(data, device=DEVICE_NAME)
            else:
                print(f"   ⚠️  No XLPP fields parsed")
            
    except Exception as e:
        print(f"❌ [{timestamp}] Error: {e}")

def on_disconnect(client, userdata, flags, reason_code, properties):
    """Called when disconnected from broker."""
    if reason_code != 0:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"⚠️  [{timestamp}] Disconnected (code: {reason_code}), reconnecting...")

# ═══════════════════════════════════════════════════════════════
# MAIN APPLICATION
# ═══════════════════════════════════════════════════════════════

def main():
    """Main application entry point."""
    print("=" * 70)
    print("🌐 LoRaWAN to InfluxDB Bridge")
    print("=" * 70)
    print(f"📍 MQTT Broker: {MQTT_BROKER}:{MQTT_PORT}")
    print(f"📍 MQTT Topic: {MQTT_TOPIC}")
    print(f"📍 Device: {DEVADDR}")
    print(f"📍 InfluxDB: {INFLUXDB_BUCKET}")
    print("=" * 70)
    
    client = mqtt.Client(
        protocol=mqtt.MQTTv311,
        callback_api_version=mqtt.CallbackAPIVersion.VERSION2
    )
    
    client.on_connect = on_connect
    client.on_message = on_message
    client.on_disconnect = on_disconnect
    
    client.reconnect_delay_set(min_delay=1, max_delay=30)
    
    try:
        client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
        
        print(f"\n🎧 Listening for sensor data... (Press Ctrl+C to stop)\n")
        
        client.loop_forever()
        
    except KeyboardInterrupt:
        print("\n\n👋 Shutting down gracefully...")
        client.disconnect()
        print("✅ Disconnected")
        
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())