import json
import binascii
import struct
import time
import base64
import requests
import paho.mqtt.client as mqtt
from Crypto.Cipher import AES
from typing import Optional

# ───────────────────── Config ─────────────────────
MQTT_BROKER = "192.168.0.102"  # ← Updated IP
MQTT_PORT   = 1883              # ← Changed from 8883 to 1883
MQTT_TOPIC  = "wazi/sensors/#"

# ABP keys from your LoRaWAN device configuration
APPSKEY = bytes.fromhex("89481B4A09CC80E1964E035E9ECD0ABF")
NWKSKEY = bytes.fromhex("F0F54D38619239041A40DBDFEE53C12F")
DEVADDR = "26011AFF"  # Device address from config

# InfluxDB Cloud
INFLUXDB_URL    = "https://eu-central-1-1.aws.cloud2.influxdata.com"
INFLUXDB_BUCKET = "wazi_sensors"
INFLUXDB_ORG    = "andguladzeluka12@gmail.com"
INFLUXDB_TOKEN  = "k7dFdwFKCIsk6bwZjnwKmry9uiw8yAkw7nye1D4ym2Wk8SX84wL41XxhSNWqtTspNnkfjbce3RXL7rT45m5CIQ=="

# ─────────────────── Decrypt (ECB) ─────────────────
def decrypt_lora_payload(payload_hex: str) -> bytes:
    # pad to 16-byte blocks for ECB if needed
    if len(payload_hex) % 32 != 0:
        pad_len = (32 - (len(payload_hex) % 32)) % 32
        payload_hex += "00" * (pad_len // 2)
    cipher = AES.new(APPSKEY, AES.MODE_ECB)
    raw = binascii.unhexlify(payload_hex)
    out = b""
    for i in range(0, len(raw), 16):
        out += cipher.decrypt(raw[i:i+16])
    return out

# ─────────────── Parse XLPP → your sensors ─────────
# Channels (example):
#   ch1 temp (0x02), ch2 humidity (0x03)
#   ch3 raindrop AO (0x06), ch4 sound AO (0x06), ch5 water AO (0x06)
def parse_xlpp(payload: bytes) -> dict:
    out = {}
    i, L = 0, len(payload)
    while i < L:
        if i + 1 >= L:
            break
        t = payload[i]
        ch = payload[i+1]
        if t == 0x02 and i+4 <= L:  # temperature (°C*10, big-endian)
            val = struct.unpack(">h", payload[i+2:i+4])[0] / 10.0
            if ch == 0x01:
                out["temperature"] = val
            else:
                out[f"temperature_ch{ch}"] = val
            i += 4
        elif t == 0x03 and i+3 <= L:  # humidity (%)
            val = payload[i+2]
            if ch == 0x02:
                out["relativehumidity"] = float(val)
            else:
                out[f"relativehumidity_ch{ch}"] = float(val)
            i += 3
        elif t == 0x06 and i+4 <= L:  # analog
            val = struct.unpack(">h", payload[i+2:i+4])[0]
            if   ch == 0x03: out["rainAO"]  = int(val)
            elif ch == 0x04: out["soundAO"] = int(val)
            elif ch == 0x05: out["waterAO"] = int(val)
            else:
                out[f"analog_ch{ch}"] = int(val)
            i += 4
        else:
            i += 1  # skip unknown
    # derived % values
    if "rainAO"  in out: out["rainPct"]  = round(max(0, min(100, (1023 - out["rainAO"]) * 100 / 1023)), 1)
    if "soundAO" in out: out["soundPct"] = round(max(0, min(100, out["soundAO"] * 100 / 1023)), 1)
    if "waterAO" in out: out["waterPct"] = round(max(0, min(100, out["waterAO"] * 100 / 1023)), 1)
    return out

# ───────────── InfluxDB line protocol write ────────
def send_to_influxdb(sensor_data: dict, device: str = "wazi-node"):
    ts_ns = int(time.time() * 1e9)
    lines = []
    for k, v in sensor_data.items():
        try:
            fv = float(v)
        except (ValueError, TypeError):
            continue
        lines.append(f"{k},device={device} value={fv} {ts_ns}")
    if not lines:
        return
    payload = "\n".join(lines)
    headers = {
        "Authorization": f"Token {INFLUXDB_TOKEN}",
        "Content-Type": "text/plain",
        "Accept": "application/json"
    }
    url = f"{INFLUXDB_URL}/api/v2/write?org={INFLUXDB_ORG}&bucket={INFLUXDB_BUCKET}&precision=ns"
    try:
        r = requests.post(url, data=payload, headers=headers, timeout=10)
        if r.status_code == 204:
            print("✅ Sent to InfluxDB:", sensor_data)
        else:
            print("❌ Influx error:", r.status_code, r.text)
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error sending to InfluxDB: {e}")

# ───── Extract hex payload from various MQTT formats ────
def extract_payload_hex(mqtt_payload: bytes) -> Optional[str]:
    # Try JSON (base64 app payload used by many gateways)
    try:
        obj = json.loads(mqtt_payload.decode("utf-8"))
        b64 = obj.get("data") or obj.get("frm_payload")
        if b64:
            return base64.b64decode(b64).hex()
        # or "payload" as hex
        if isinstance(obj.get("payload"), str):
            ph = obj["payload"].strip().lower()
            if ph and all(c in "0123456789abcdef" for c in ph):
                return ph
    except Exception:
        pass
    # ASCII hex?
    try:
        s = mqtt_payload.decode("utf-8").strip().lower()
        if s and all(c in "0123456789abcdef" for c in s):
            return s
    except Exception:
        pass
    # Raw binary bytes
    return mqtt_payload.hex()

# ─────────────── MQTT v2 Callbacks ────────────────
def on_connect(client, userdata, flags, reason_code, properties):
    """Callback for when the client connects to the broker."""
    if reason_code == 0:
        print(f"🔌 MQTT connected successfully, subscribing to {MQTT_TOPIC}")
        client.subscribe(MQTT_TOPIC, qos=0)
    else:
        print(f"❌ MQTT connection failed with code: {reason_code}")

def on_message(client, userdata, msg):
    """Callback for when a message is received."""
    try:
        payload_hex = extract_payload_hex(msg.payload)
        if not payload_hex:
            print(f"⚠️  No payload to decode on {msg.topic}")
            return

        print(f"📡 {msg.topic}  HEX:{payload_hex}")
        decrypted = decrypt_lora_payload(payload_hex)
        print(f"🔓 Decrypted (hex): {decrypted.hex()}")

        data = parse_xlpp(decrypted)
        if data:
            send_to_influxdb(data, device="wazi-node")
        else:
            print("ℹ️  No XLPP fields parsed.")
    except Exception as e:
        print(f"❌ on_message error: {e}")

def on_disconnect(client, userdata, flags, reason_code, properties):
    """Callback for when the client disconnects."""
    if reason_code != 0:
        print(f"⚠️  Unexpected disconnect (code: {reason_code}), will reconnect...")

# ───────────────────── Main ───────────────────────
if __name__ == "__main__":
    client = mqtt.Client(
        protocol=mqtt.MQTTv311,
        callback_api_version=mqtt.CallbackAPIVersion.VERSION2
    )
    
    # Set callbacks
    client.on_connect = on_connect
    client.on_message = on_message
    client.on_disconnect = on_disconnect

    # NO TLS - broker is on standard port 1883
    # If your broker requires authentication, uncomment:
    # client.username_pw_set("username", "password")

    # Reconnect settings
    client.reconnect_delay_set(min_delay=1, max_delay=30)

    try:
        print(f"📡 Connecting to {MQTT_BROKER}:{MQTT_PORT}...")
        client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
        print("📡 Listening for real-time sensor data from Wazi Gateway…")
        client.loop_forever()
    except KeyboardInterrupt:
        print("\n👋 Shutting down gracefully...")
        client.disconnect()
    except Exception as e:
        print(f"❌ Fatal error: {e}")