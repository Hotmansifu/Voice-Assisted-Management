"""
MQTT Test Publisher
Publishes fake LoRa sensor data to test your connection.py script
Run this while connection.py is running to verify everything works.
"""

import paho.mqtt.client as mqtt
import json
import base64
import time

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION - Must match your connection.py settings
# ═══════════════════════════════════════════════════════════════

MQTT_BROKER = "192.168.0.102"
MQTT_PORT = 1883
MQTT_TOPIC = "wazi/sensors/test"  # Will publish to this topic

# ═══════════════════════════════════════════════════════════════
# TEST PAYLOADS - Encrypted XLPP data examples
# ═══════════════════════════════════════════════════════════════

test_payloads = [
    {
        "hex": "020100640302ff",
        "description": "Temperature: 10.0°C, Humidity: 255%"
    },
    {
        "hex": "0201009c030232",
        "description": "Temperature: 15.6°C, Humidity: 50%"
    },
    {
        "hex": "02010078030241060301f4060400c8060500fa",
        "description": "Temp: 12.0°C, Humidity: 65%, Rain: 500, Sound: 200, Water: 250"
    }
]

# ═══════════════════════════════════════════════════════════════
# MQTT CALLBACKS
# ═══════════════════════════════════════════════════════════════

def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        print("✅ Connected to MQTT broker")
    else:
        print(f"❌ Connection failed: {reason_code}")

# ═══════════════════════════════════════════════════════════════
# MAIN TEST FUNCTION
# ═══════════════════════════════════════════════════════════════

def main():
    print("=" * 70)
    print("🧪 MQTT Test Publisher - Fake LoRa Sensor Data")
    print("=" * 70)
    print(f"📍 Broker: {MQTT_BROKER}:{MQTT_PORT}")
    print(f"📍 Topic: {MQTT_TOPIC}")
    print("=" * 70)
    
    # Create MQTT client
    client = mqtt.Client(
        protocol=mqtt.MQTTv311,
        callback_api_version=mqtt.CallbackAPIVersion.VERSION2
    )
    
    client.on_connect = on_connect
    
    # Connect to broker
    print(f"\n🔌 Connecting to {MQTT_BROKER}:{MQTT_PORT}...")
    try:
        client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
        client.loop_start()
        time.sleep(2)  # Wait for connection
    except Exception as e:
        print(f"❌ Connection error: {e}")
        return 1
    
    print("\n" + "=" * 70)
    print("📡 Publishing Test Messages")
    print("=" * 70)
    print("\n⚠️  Make sure connection.py is running in another terminal!")
    print("   You should see it decrypt and process these messages.\n")
    
    # Publish each test payload
    for i, payload in enumerate(test_payloads, 1):
        print(f"\n📤 Test Message {i}/{len(test_payloads)}")
        print(f"   Description: {payload['description']}")
        print(f"   Hex Payload: {payload['hex']}")
        
        # Format 1: Raw hex string (simplest format)
        topic = f"{MQTT_TOPIC}/raw"
        client.publish(topic, payload['hex'])
        print(f"   ✅ Published to: {topic}")
        
        # Format 2: JSON with base64 (common gateway format)
        hex_bytes = bytes.fromhex(payload['hex'])
        b64_data = base64.b64encode(hex_bytes).decode('utf-8')
        
        json_payload = json.dumps({
            "data": b64_data,
            "devEUI": "0000000000000001",
            "timestamp": int(time.time()),
            "rssi": -65,
            "snr": 8.5
        })
        
        topic_json = f"{MQTT_TOPIC}/json"
        client.publish(topic_json, json_payload)
        print(f"   ✅ Published to: {topic_json} (JSON format)")
        
        time.sleep(3)  # Wait between messages
    
    print("\n" + "=" * 70)
    print("✅ All test messages published!")
    print("=" * 70)
    print("\n💡 Check your connection.py terminal for:")
    print("   • Decrypted hex data")
    print("   • Parsed sensor values")
    print("   • InfluxDB upload confirmation")
    
    # Cleanup
    time.sleep(2)
    client.loop_stop()
    client.disconnect()
    
    return 0

if __name__ == "__main__":
    exit(main())